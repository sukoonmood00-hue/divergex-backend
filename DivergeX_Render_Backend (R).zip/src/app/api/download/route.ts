import { NextRequest, NextResponse } from "next/server";
import { readFile, access } from "fs/promises";
import { constants } from "fs";
import path from "path";

const DOWNLOAD_DIR = "/home/z/my-project/download";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const filename = searchParams.get("file");

  if (!filename) {
    return NextResponse.json(
      { error: "File parameter is required" },
      { status: 400 }
    );
  }

  // Security: prevent directory traversal
  const sanitizedFilename = path.basename(filename);
  const filePath = path.join(DOWNLOAD_DIR, sanitizedFilename);

  // Ensure the file is within the download directory
  if (!filePath.startsWith(DOWNLOAD_DIR)) {
    return NextResponse.json(
      { error: "Invalid file path" },
      { status: 403 }
    );
  }

  try {
    // Check if file exists
    await access(filePath, constants.R_OK);

    // Read the file
    const fileBuffer = await readFile(filePath);

    // Return the file with appropriate headers
    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${sanitizedFilename}"`,
        "Content-Length": fileBuffer.length.toString(),
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: "File not found" },
      { status: 404 }
    );
  }
}
