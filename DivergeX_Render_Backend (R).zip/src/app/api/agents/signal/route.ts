import { NextResponse } from 'next/server';

const agentNames = [
  'NIFTY_HAWK', 'BANKNIFTY_EAGLE', 'FINNIFTY_FALCON', 
  'MIDCAP_HUNTER', 'SENSEX_TRACKER', 'NIFTY_PREDATOR'
];

const symbols = ['NIFTY 50', 'BANK NIFTY', 'FIN NIFTY', 'MIDCAP', 'SENSEX'];
const timeframes = ['60min', '15min', '5min'];
const agentTypes = ['SINGLE', 'DOUBLE', 'INVERSE_ETF', 'PORTFOLIO'];

function generateAgents() {
  const agents = [];
  
  for (const tf of timeframes) {
    for (const type of agentTypes) {
      for (let i = 0; i < 2; i++) {
        agents.push({
          id: `${tf}_${type}_${i}`.toLowerCase(),
          name: agentNames[Math.floor(Math.random() * agentNames.length)],
          timeframe: tf,
          agentType: type,
          symbol: symbols[Math.floor(Math.random() * symbols.length)],
          status: Math.random() > 0.2 ? 'ACTIVE' : 'PAUSED',
          winRate: 55 + Math.floor(Math.random() * 30),
          totalTrades: 100 + Math.floor(Math.random() * 500),
          profitFactor: 1.2 + Math.random() * 1.5,
          currentSignal: Math.random() > 0.3 ? {
            type: Math.random() > 0.5 ? 'BUY' : 'SELL',
            confidence: 60 + Math.floor(Math.random() * 35),
            entry: 23000 + Math.random() * 500
          } : null,
          sharpeRatio: 0.5 + Math.random() * 2
        });
      }
    }
  }
  
  return agents;
}

export async function GET() {
  return NextResponse.json({
    agents: generateAgents(),
    lastUpdated: new Date().toISOString()
  });
}
