import { NextResponse } from 'next/server';

const brokerages = ['Zerodha', 'Angel One', 'Upstox', 'Groww'];
const symbols = ['NIFTY 50', 'BANK NIFTY', 'FIN NIFTY'];
const timeframes = ['60min', '15min', '5min'];
const agentTypes = ['SINGLE', 'DOUBLE', 'INVERSE_ETF', 'PORTFOLIO'];

function generateBrokerageAgents() {
  const agents = [];
  
  for (const tf of timeframes) {
    for (const type of agentTypes) {
      const connected = Math.random() > 0.3;
      agents.push({
        id: `brokerage_${tf}_${type}`.toLowerCase(),
        name: `BROKER_${brokerages[Math.floor(Math.random() * brokerages.length)]}`.toUpperCase(),
        timeframe: tf,
        agentType: type,
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        status: connected ? 'ACTIVE' : 'DISCONNECTED',
        brokerage: {
          name: brokerages[Math.floor(Math.random() * brokerages.length)],
          connected,
          latency: connected ? Math.floor(20 + Math.random() * 100) : 0
        },
        account: {
          balance: 50000 + Math.floor(Math.random() * 150000),
          dayPnL: parseFloat(((Math.random() - 0.4) * 5000).toFixed(2))
        },
        flmAnalysis: {
          marketCondition: ['TRENDING', 'RANGING', 'VOLATILE', 'CALM'][Math.floor(Math.random() * 4)],
          signal: ['BUY', 'SELL', 'WAIT'][Math.floor(Math.random() * 3)],
          confidence: 40 + Math.floor(Math.random() * 50)
        },
        performance: {
          winRate: 45 + Math.floor(Math.random() * 35),
          netPnL: parseFloat(((Math.random() - 0.3) * 50000).toFixed(2))
        }
      });
    }
  }
  
  return agents;
}

export async function GET() {
  return NextResponse.json({
    agents: generateBrokerageAgents(),
    lastUpdated: new Date().toISOString()
  });
}
