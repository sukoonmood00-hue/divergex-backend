import { NextResponse } from 'next/server';

const agentNames = ['VIRTUAL_ALPHA', 'VIRTUAL_BETA', 'VIRTUAL_GAMMA', 'VIRTUAL_DELTA'];
const symbols = ['NIFTY 50', 'BANK NIFTY', 'FIN NIFTY'];
const timeframes = ['60min', '15min', '5min'];
const agentTypes = ['SINGLE', 'DOUBLE', 'INVERSE_ETF', 'PORTFOLIO'];

function generateVirtualAgents() {
  const agents = [];
  
  for (const tf of timeframes) {
    for (const type of agentTypes) {
      const profitLossPercent = (Math.random() - 0.3) * 30;
      agents.push({
        id: `virtual_${tf}_${type}`.toLowerCase(),
        name: agentNames[Math.floor(Math.random() * agentNames.length)],
        timeframe: tf,
        agentType: type,
        symbol: symbols[Math.floor(Math.random() * symbols.length)],
        status: Math.random() > 0.3 ? 'ACTIVE' : 'PAUSED',
        virtualBalance: {
          current: 100000 + Math.floor(Math.random() * 50000),
          profitLossPercent: parseFloat(profitLossPercent.toFixed(2))
        },
        moneyManagement: {
          riskPerTrade: 1 + Math.floor(Math.random() * 3),
          positionSizing: ['Fixed', 'Kelly', 'Risk Parity'][Math.floor(Math.random() * 3)]
        },
        currentPosition: Math.random() > 0.5 ? {
          type: Math.random() > 0.5 ? 'LONG' : 'SHORT',
          unrealizedPnL: parseFloat(((Math.random() - 0.5) * 5000).toFixed(2))
        } : null,
        stats: {
          winRate: 50 + Math.floor(Math.random() * 30),
          profitFactor: parseFloat((1 + Math.random() * 1.5).toFixed(2))
        }
      });
    }
  }
  
  return agents;
}

export async function GET() {
  return NextResponse.json({
    agents: generateVirtualAgents(),
    lastUpdated: new Date().toISOString()
  });
}
