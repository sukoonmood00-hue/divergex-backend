import { NextResponse } from 'next/server';

// Generate realistic OHLC data
function generateOHLCData(basePrice: number, count: number) {
  const data: { x: number; y: [number, number, number, number] }[] = [];
  let currentPrice = basePrice;
  const now = Date.now();
  
  for (let i = count; i >= 0; i--) {
    const time = now - (i * 15 * 60 * 1000); // 15 min candles
    const volatility = 0.002;
    const open = currentPrice;
    const change = (Math.random() - 0.5) * 2 * currentPrice * volatility;
    const high = open + Math.abs(change) + Math.random() * currentPrice * volatility;
    const low = open - Math.abs(change) - Math.random() * currentPrice * volatility;
    const close = open + change;
    
    data.push({
      x: time,
      y: [parseFloat(open.toFixed(2)), parseFloat(high.toFixed(2)), parseFloat(low.toFixed(2)), parseFloat(close.toFixed(2))]
    });
    
    currentPrice = close;
  }
  
  return data;
}

// Generate EMA data
function generateEMAData(ohlc: { x: number; y: [number, number, number, number] }[], period: number) {
  const multiplier = 2 / (period + 1);
  const data: { x: number; y: number | null }[] = [];
  
  // Calculate SMA for first period
  let ema = 0;
  for (let i = 0; i < ohlc.length; i++) {
    if (i < period - 1) {
      data.push({ x: ohlc[i].x, y: null });
    } else if (i === period - 1) {
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += ohlc[j].y[3]; // close price
      }
      ema = sum / period;
      data.push({ x: ohlc[i].x, y: parseFloat(ema.toFixed(2)) });
    } else {
      ema = (ohlc[i].y[3] - ema) * multiplier + ema;
      data.push({ x: ohlc[i].x, y: parseFloat(ema.toFixed(2)) });
    }
  }
  
  return data;
}

export async function GET() {
  const basePrice = 23150 + (Math.random() - 0.5) * 100;
  const change = (Math.random() - 0.5) * 2;
  const strength = Math.floor(Math.random() * 80) + 20;
  
  const ohlc = generateOHLCData(basePrice, 100);
  const ema9 = generateEMAData(ohlc, 9);
  const ema21 = generateEMAData(ohlc, 21);
  
  const data = {
    lp: parseFloat(basePrice.toFixed(2)),
    change: parseFloat(change.toFixed(2)),
    strength: strength,
    total_div: Math.floor(Math.random() * 5),
    oscillators: [
      { name: 'RSI', value: 30 + Math.random() * 40, bull: Math.random() > 0.7, bear: Math.random() > 0.7, color: '#00ffff' },
      { name: 'MFI', value: 20 + Math.random() * 50, bull: Math.random() > 0.7, bear: Math.random() > 0.7, color: '#ff0033' },
      { name: 'STOCH', value: 10 + Math.random() * 60, bull: Math.random() > 0.7, bear: Math.random() > 0.7, color: '#00ff99' },
      { name: 'MACD', value: (Math.random() - 0.5) * 2, bull: Math.random() > 0.7, bear: Math.random() > 0.7, color: '#ff6600' },
      { name: 'CCI', value: (Math.random() - 0.5) * 200, bull: Math.random() > 0.7, bear: Math.random() > 0.7, color: '#ff00ff' },
      { name: 'SRSI', value: 20 + Math.random() * 60, bull: Math.random() > 0.7, bear: Math.random() > 0.7, color: '#ffffff' }
    ],
    structure: {
      text: change > 0 ? 'BULLISH' : 'BEARISH',
      color: change > 0 ? '#3fb950' : '#f85149',
      strength: strength,
      type: change > 0 ? 'bullish' : 'bearish'
    },
    indicators: {
      rsi: Math.random() > 0.5 ? 'green' : Math.random() > 0.5 ? 'red' : 'neutral',
      macd: Math.random() > 0.5 ? 'green' : Math.random() > 0.5 ? 'red' : 'neutral',
      volume: Math.random() > 0.5 ? 'green' : 'neutral',
      trend: change > 0 ? 'green' : 'red'
    },
    operation: strength > 70 ? (change > 0 ? 'BUY' : 'SELL') : 'WAIT',
    signal_reason: strength > 70 
      ? `Strong ${change > 0 ? 'bullish' : 'bearish'} divergence detected across multiple oscillators`
      : 'No Clear Signal - Wait for Confirmation',
    chart_data: {
      ohlc,
      ema9,
      ema21,
      markers: []
    }
  };
  
  return NextResponse.json(data);
}
