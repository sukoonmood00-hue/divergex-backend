import { NextResponse } from 'next/server';

export async function GET() {
  const currentPrice = 23150 + (Math.random() - 0.5) * 100;
  
  const predictions = [
    { timeframe: '1H', direction: Math.random() > 0.5 ? 'BULLISH' : 'BEARISH', targetPrice: currentPrice * (1 + (Math.random() - 0.5) * 0.01), confidence: 70 + Math.floor(Math.random() * 25), support: currentPrice * 0.995, resistance: currentPrice * 1.005 },
    { timeframe: '4H', direction: Math.random() > 0.5 ? 'BULLISH' : 'BEARISH', targetPrice: currentPrice * (1 + (Math.random() - 0.5) * 0.02), confidence: 60 + Math.floor(Math.random() * 30), support: currentPrice * 0.99, resistance: currentPrice * 1.01 },
    { timeframe: '1D', direction: Math.random() > 0.5 ? 'BULLISH' : 'BEARISH', targetPrice: currentPrice * (1 + (Math.random() - 0.5) * 0.03), confidence: 55 + Math.floor(Math.random() * 30), support: currentPrice * 0.985, resistance: currentPrice * 1.015 },
    { timeframe: '1W', direction: Math.random() > 0.5 ? 'BULLISH' : 'BEARISH', targetPrice: currentPrice * (1 + (Math.random() - 0.5) * 0.05), confidence: 50 + Math.floor(Math.random() * 30), support: currentPrice * 0.98, resistance: currentPrice * 1.02 }
  ];
  
  return NextResponse.json({
    currentPrice: parseFloat(currentPrice.toFixed(2)),
    predictions,
    lastUpdated: new Date().toISOString()
  });
}
