import { NextResponse } from 'next/server';

const signals = [
  { symbol: 'RELIANCE', type: 'BUY', desc: 'Bullish divergence on daily RSI with volume confirmation' },
  { symbol: 'TATASTEEL', type: 'SELL', desc: 'Bearish breakdown below key support with high volume' },
  { symbol: 'HDFCBANK', type: 'BUY', desc: 'Order block retest with bullish engulfing pattern' },
  { symbol: 'INFY', type: 'BUY', desc: 'Liquidity sweep followed by bullish rejection' },
  { symbol: 'ICICIBANK', type: 'SELL', desc: 'Double top formation with divergence confirmation' },
  { symbol: 'SBIN', type: 'BUY', desc: 'Support retest with RSI oversold condition' },
  { symbol: 'BHARTIARTL', type: 'BUY', desc: 'Breakout from consolidation with volume surge' },
  { symbol: 'TCS', type: 'SELL', desc: 'Bearish flag breakdown in progress' }
];

export async function GET() {
  const data = signals.map(s => ({
    ...s,
    prob: 60 + Math.floor(Math.random() * 30),
    price: 500 + Math.floor(Math.random() * 3000),
    change: parseFloat(((Math.random() - 0.4) * 5).toFixed(2))
  }));
  
  return NextResponse.json({
    signals: data,
    lastUpdated: new Date().toISOString()
  });
}
