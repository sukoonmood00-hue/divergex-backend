import { NextResponse } from 'next/server';

export async function GET() {
  const isRunning = Math.random() > 0.3;
  const dailyPnL = (Math.random() - 0.3) * 10000;
  const totalTrades = 50 + Math.floor(Math.random() * 200);
  const winRate = 50 + Math.floor(Math.random() * 25);
  
  const activeTrades = [];
  const numActive = Math.floor(Math.random() * 3);
  
  for (let i = 0; i < numActive; i++) {
    activeTrades.push({
      id: `trade_${Date.now()}_${i}`,
      symbol: ['NIFTY 50', 'BANK NIFTY', 'FIN NIFTY'][Math.floor(Math.random() * 3)],
      type: Math.random() > 0.5 ? 'BUY' : 'SELL',
      entryPrice: 23000 + Math.random() * 500,
      pnl: parseFloat(((Math.random() - 0.4) * 5000).toFixed(2)),
      reason: ['Divergence signal', 'Order block retest', 'Liquidity sweep', 'AI prediction'][Math.floor(Math.random() * 4)]
    });
  }
  
  const pendingSignals = [];
  const numPending = Math.floor(Math.random() * 3);
  
  for (let i = 0; i < numPending; i++) {
    pendingSignals.push({
      id: `pending_${Date.now()}_${i}`,
      symbol: ['NIFTY 50', 'BANK NIFTY', 'FIN NIFTY'][Math.floor(Math.random() * 3)],
      type: Math.random() > 0.5 ? 'BUY' : 'SELL',
      confidence: 65 + Math.floor(Math.random() * 30),
      entryPrice: 23000 + Math.random() * 500,
      reason: ['Awaiting confirmation', 'Waiting for price level', 'Validating signal'][Math.floor(Math.random() * 3)]
    });
  }
  
  const logs = [
    { time: new Date().toISOString(), level: 'INFO', message: 'System initialized successfully' },
    { time: new Date().toISOString(), level: 'INFO', message: 'Connected to market data feed' },
    { time: new Date().toISOString(), level: isRunning ? 'INFO' : 'WARN', message: isRunning ? 'Auto-trading enabled' : 'Auto-trading paused' },
    { time: new Date().toISOString(), level: 'INFO', message: `${totalTrades} trades analyzed today` },
    { time: new Date().toISOString(), level: dailyPnL > 0 ? 'INFO' : 'WARN', message: `Daily P&L: ₹${dailyPnL.toFixed(0)}` },
    { time: new Date().toISOString(), level: 'DEBUG', message: 'Risk parameters validated' }
  ];
  
  return NextResponse.json({
    config: {
      enabled: true,
      strategy: 'DIVERGENCE_OB_COMBO',
      maxRiskPerTrade: 2,
      maxTradesPerDay: 10,
      minConfidence: 70
    },
    status: {
      isRunning,
      mode: 'LIVE',
      currentBalance: 100000 + Math.floor(Math.random() * 50000),
      dailyPnL: parseFloat(dailyPnL.toFixed(2)),
      openPositions: numActive,
      connectedBroker: 'Zerodha',
      signalsGenerated: 20 + Math.floor(Math.random() * 30),
      signalsExecuted: 10 + Math.floor(Math.random() * 20)
    },
    stats: {
      totalTrades,
      winRate,
      totalPnL: parseFloat(((Math.random() - 0.3) * 50000).toFixed(2)),
      profitFactor: parseFloat((1 + Math.random() * 1.5).toFixed(2))
    },
    activeTrades,
    recentTrades: [],
    pendingSignals,
    logs,
    lastUpdated: new Date().toISOString()
  });
}
