import { NextResponse } from 'next/server';

export async function GET() {
  const currentPrice = 23150 + (Math.random() - 0.5) * 100;
  
  const bullishBlocks = [];
  const bearishBlocks = [];
  
  // Generate bullish order blocks
  for (let i = 0; i < 5; i++) {
    const low = currentPrice * (0.98 - i * 0.005);
    bullishBlocks.push({
      id: `bull_${i}`,
      type: 'BULLISH',
      high: parseFloat((low + 15 + Math.random() * 10).toFixed(2)),
      low: parseFloat(low.toFixed(2)),
      strength: 50 + Math.floor(Math.random() * 40),
      status: ['FRESH', 'MITIGATED', 'BROKEN'][Math.floor(Math.random() * 3)],
      zones: {
        entry: parseFloat((low + 5).toFixed(2)),
        stopLoss: parseFloat((low - 10).toFixed(2)),
        takeProfit: parseFloat((low + 50).toFixed(2))
      },
      probability: 50 + Math.floor(Math.random() * 35),
      distancePercent: parseFloat(((currentPrice - low) / currentPrice * 100).toFixed(2))
    });
  }
  
  // Generate bearish order blocks
  for (let i = 0; i < 5; i++) {
    const high = currentPrice * (1.02 + i * 0.005);
    bearishBlocks.push({
      id: `bear_${i}`,
      type: 'BEARISH',
      high: parseFloat(high.toFixed(2)),
      low: parseFloat((high - 15 - Math.random() * 10).toFixed(2)),
      strength: 50 + Math.floor(Math.random() * 40),
      status: ['FRESH', 'MITIGATED', 'BROKEN'][Math.floor(Math.random() * 3)],
      zones: {
        entry: parseFloat((high - 5).toFixed(2)),
        stopLoss: parseFloat((high + 10).toFixed(2)),
        takeProfit: parseFloat((high - 50).toFixed(2))
      },
      probability: 50 + Math.floor(Math.random() * 35),
      distancePercent: parseFloat(((high - currentPrice) / currentPrice * 100).toFixed(2))
    });
  }
  
  const signalType = Math.random() > 0.5 ? 'BUY' : Math.random() > 0.5 ? 'SELL' : 'WAIT';
  
  return NextResponse.json({
    symbol: 'NIFTY 50',
    currentPrice: parseFloat(currentPrice.toFixed(2)),
    bullishBlocks: bullishBlocks.sort((a, b) => a.distancePercent - b.distancePercent),
    bearishBlocks: bearishBlocks.sort((a, b) => a.distancePercent - b.distancePercent),
    activeSignal: {
      type: signalType,
      block: signalType === 'BUY' ? bullishBlocks[0] : signalType === 'SELL' ? bearishBlocks[0] : null,
      confidence: 60 + Math.floor(Math.random() * 30),
      reason: signalType !== 'WAIT' 
        ? `Fresh ${signalType.toLowerCase()}ish order block detected near current price`
        : 'No clear order block signal'
    },
    smartMoneyFlow: ['ACCUMULATION', 'DISTRIBUTION', 'NEUTRAL'][Math.floor(Math.random() * 3)],
    institutionalActivity: {
      level: ['HIGH', 'MEDIUM', 'LOW'][Math.floor(Math.random() * 3)],
      direction: ['BUYING', 'SELLING', 'NEUTRAL'][Math.floor(Math.random() * 3)],
      volume: Math.floor(Math.random() * 100000)
    },
    lastUpdated: new Date().toISOString()
  });
}
