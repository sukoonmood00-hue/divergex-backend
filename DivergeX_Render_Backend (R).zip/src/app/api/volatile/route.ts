import { NextResponse } from 'next/server';

const stocks = [
  'ADANIENT', 'ADANIPORTS', 'APOLLOHOSP', 'BAJAJFINSV', 'BANDHANBNK',
  'BHEL', 'BPCL', 'COALINDIA', 'GAIL', 'HINDALCO',
  'INDUSINDBK', 'JSWSTEEL', 'NTPC', 'POWERGRID', 'TATASTEEL'
];

export async function GET() {
  const data = stocks.map(symbol => ({
    symbol,
    price: 100 + Math.floor(Math.random() * 2000),
    change: parseFloat(((Math.random() - 0.5) * 8).toFixed(2)),
    volatility: parseFloat((3 + Math.random() * 7).toFixed(2)),
    risk: ['LOW', 'MEDIUM', 'HIGH'][Math.floor(Math.random() * 3)]
  })).sort((a, b) => b.volatility - a.volatility);
  
  return NextResponse.json({
    stocks: data,
    lastUpdated: new Date().toISOString()
  });
}
