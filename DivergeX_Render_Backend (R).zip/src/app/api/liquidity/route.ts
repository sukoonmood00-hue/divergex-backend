import { NextResponse } from 'next/server';

export async function GET() {
  const currentPrice = 23150 + (Math.random() - 0.5) * 100;
  
  // Generate liquidity zones
  const liquidityZones = [];
  
  // Buy-side liquidity (above price)
  for (let i = 0; i < 4; i++) {
    const price = currentPrice * (1.005 + i * 0.003);
    liquidityZones.push({
      id: `buyside_${i}`,
      type: 'BUY_SIDE',
      price: parseFloat(price.toFixed(2)),
      strength: 50 + Math.floor(Math.random() * 40),
      status: ['ACTIVE', 'SWEPT', 'PENDING'][Math.floor(Math.random() * 3)],
      distance: parseFloat(((price - currentPrice) / currentPrice * 100).toFixed(2))
    });
  }
  
  // Sell-side liquidity (below price)
  for (let i = 0; i < 4; i++) {
    const price = currentPrice * (0.995 - i * 0.003);
    liquidityZones.push({
      id: `sellside_${i}`,
      type: 'SELL_SIDE',
      price: parseFloat(price.toFixed(2)),
      strength: 50 + Math.floor(Math.random() * 40),
      status: ['ACTIVE', 'SWEPT', 'PENDING'][Math.floor(Math.random() * 3)],
      distance: parseFloat(((currentPrice - price) / currentPrice * 100).toFixed(2))
    });
  }
  
  // Generate recent sweeps
  const recentSweeps = [];
  for (let i = 0; i < 3; i++) {
    const isBullish = Math.random() > 0.5;
    recentSweeps.push({
      id: `sweep_${i}`,
      type: isBullish ? 'BULLISH_SWEEP' : 'BEARISH_SWEEP',
      sweptLevel: parseFloat((currentPrice * (isBullish ? 0.99 - i * 0.005 : 1.01 + i * 0.005)).toFixed(2)),
      confidence: 60 + Math.floor(Math.random() * 30),
      signal: isBullish ? 'BUY' : 'SELL',
      entryPrice: parseFloat((currentPrice * (isBullish ? 1.001 : 0.999)).toFixed(2)),
      stopLoss: parseFloat((currentPrice * (isBullish ? 0.995 : 1.005)).toFixed(2)),
      takeProfit: parseFloat((currentPrice * (isBullish ? 1.01 : 0.99)).toFixed(2))
    });
  }
  
  const detected = Math.random() > 0.5;
  
  return NextResponse.json({
    symbol: 'NIFTY 50',
    currentPrice: parseFloat(currentPrice.toFixed(2)),
    liquidityZones: liquidityZones.sort((a, b) => a.distance - b.distance),
    recentSweeps,
    activeSweepSignal: {
      detected,
      action: detected ? (Math.random() > 0.5 ? 'BUY' : 'SELL') : 'WAIT',
      confidence: detected ? 70 + Math.floor(Math.random() * 25) : 0,
      reason: detected 
        ? 'Liquidity sweep detected - potential reversal zone'
        : 'No active sweep signal'
    },
    liquidityMap: {
      imbalance: Math.random() > 0.5 ? 'BUY_PRESSURE' : 'SELL_PRESSURE',
      totalBuySide: Math.floor(10000 + Math.random() * 50000),
      totalSellSide: Math.floor(10000 + Math.random() * 50000)
    },
    stopHuntProbability: 30 + Math.floor(Math.random() * 50),
    nextTargets: {
      buySide: [
        parseFloat((currentPrice * 1.01).toFixed(2)),
        parseFloat((currentPrice * 1.02).toFixed(2)),
        parseFloat((currentPrice * 1.03).toFixed(2))
      ],
      sellSide: [
        parseFloat((currentPrice * 0.99).toFixed(2)),
        parseFloat((currentPrice * 0.98).toFixed(2)),
        parseFloat((currentPrice * 0.97).toFixed(2))
      ]
    },
    lastUpdated: new Date().toISOString()
  });
}
