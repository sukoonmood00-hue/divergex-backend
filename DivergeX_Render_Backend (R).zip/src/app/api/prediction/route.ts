import { NextResponse } from 'next/server';

export async function GET() {
  const currentPrice = 23150 + (Math.random() - 0.5) * 100;
  
  const predictions = [
    { timeframe: 'Short-term', direction: Math.random() > 0.5 ? 'BULLISH' : 'BEARISH', targetPrice: currentPrice * (1 + (Math.random() - 0.5) * 0.015), stopLoss: currentPrice * 0.99, probability: 60 + Math.floor(Math.random() * 30), confidence: 65 + Math.floor(Math.random() * 25) },
    { timeframe: 'Medium-term', direction: Math.random() > 0.5 ? 'BULLISH' : 'BEARISH', targetPrice: currentPrice * (1 + (Math.random() - 0.5) * 0.03), stopLoss: currentPrice * 0.985, probability: 55 + Math.floor(Math.random() * 30), confidence: 60 + Math.floor(Math.random() * 25) },
    { timeframe: 'Long-term', direction: Math.random() > 0.5 ? 'BULLISH' : 'BEARISH', targetPrice: currentPrice * (1 + (Math.random() - 0.5) * 0.05), stopLoss: currentPrice * 0.98, probability: 50 + Math.floor(Math.random() * 30), confidence: 55 + Math.floor(Math.random() * 25) }
  ];
  
  const signals = [
    { name: 'RSI', value: 30 + Math.random() * 40, signal: Math.random() > 0.5 ? 'BUY' : Math.random() > 0.5 ? 'SELL' : 'NEUTRAL', weight: 0.15 },
    { name: 'MACD', value: (Math.random() - 0.5) * 2, signal: Math.random() > 0.5 ? 'BUY' : Math.random() > 0.5 ? 'SELL' : 'NEUTRAL', weight: 0.2 },
    { name: 'EMA Cross', value: Math.random() > 0.5 ? 1 : -1, signal: Math.random() > 0.5 ? 'BUY' : 'SELL', weight: 0.25 },
    { name: 'Volume', value: Math.random() * 2, signal: Math.random() > 0.5 ? 'BUY' : 'NEUTRAL', weight: 0.15 },
    { name: 'Bollinger', value: Math.random() * 100, signal: Math.random() > 0.5 ? 'BUY' : Math.random() > 0.5 ? 'SELL' : 'NEUTRAL', weight: 0.1 },
    { name: 'ADX', value: 20 + Math.random() * 30, signal: Math.random() > 0.6 ? 'BUY' : Math.random() > 0.5 ? 'SELL' : 'NEUTRAL', weight: 0.15 }
  ];
  
  const overallScore = signals.reduce((acc, s) => {
    if (s.signal === 'BUY') return acc + s.weight * 100;
    if (s.signal === 'SELL') return acc - s.weight * 100;
    return acc;
  }, 50);
  
  return NextResponse.json({
    symbol: 'NIFTY 50',
    currentPrice: parseFloat(currentPrice.toFixed(2)),
    predictions,
    signals,
    overallScore: parseFloat(Math.max(0, Math.min(100, overallScore)).toFixed(1)),
    riskLevel: overallScore > 60 ? 'LOW' : overallScore < 40 ? 'HIGH' : 'MEDIUM',
    marketPhase: Math.random() > 0.5 ? 'TRENDING' : 'RANGING',
    lastUpdated: new Date().toISOString()
  });
}
