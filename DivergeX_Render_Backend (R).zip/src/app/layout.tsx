import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DivergeX AI Market - AI Trading System",
  description: "Advanced AI-powered trading system with JOAT Divergence detection, 6 Signal Agents, AI Prediction Engine, Auto Trading, and Virtual Trading for NIFTY & BANK NIFTY.",
  keywords: ["DivergeX AI Market", "AI Trading", "NIFTY", "BANK NIFTY", "Divergence", "Signal Agents", "Auto Trading", "JOAT", "AI Prediction"],
  authors: [{ name: "Dafda Rohit" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "DivergeX AI Market - AI Trading System",
    description: "Advanced AI-powered trading with JOAT Divergence System",
    url: "https://divergex.ai",
    siteName: "DivergeX AI Market",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "DivergeX AI Market - AI Trading System",
    description: "Advanced AI-powered trading with JOAT Divergence System",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
