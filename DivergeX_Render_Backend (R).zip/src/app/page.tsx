'use client';

import { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';

const ApexCharts = dynamic(() => import('react-apexcharts'), { ssr: false });

const FLASK_API = 'https://rohit-bxml.onrender.com';

type TabType = 'live' | 'ai_tools' | 'wallet' | 'admin' | 'about';

// ============================================
// TYPES
// ============================================
interface Oscillator {
  name: string;
  value: number;
  bull: boolean;
  bear: boolean;
  color: string;
}

interface Agent {
  name: string;
  icon: string;
  signal: string;
  strength: number;
  reason: string;
  accuracy: number;
}

interface Prediction {
  direction: string;
  action: string;
  confidence: number;
  signals: string[];
  current_price: number;
  target1: number;
  target2: number;
  stoploss: number;
}

// ============================================
// LIVE TAB
// ============================================
function LiveTab({ data, niftyData }: { data: any; niftyData: any }) {
  return (
    <div className="space-y-4">
      {/* BANK NIFTY */}
      <div className="bg-gradient-to-r from-[#0d1117] to-[#161b22] rounded-xl p-5 border border-[#f85149]/30">
        <div className="flex items-center gap-2 mb-3">
          <span className="px-2 py-1 bg-[#f85149]/20 text-[#f85149] text-xs font-bold rounded animate-pulse">🔴 LIVE</span>
          <span className="text-[#c9d1d9] font-bold text-lg">BANK NIFTY</span>
        </div>
        <div className="text-4xl font-bold text-[#c9d1d9]">{data?.lp?.toFixed(2) || '---'}</div>
        <div className={`text-xl font-bold mt-2 ${data?.change >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
          {data?.change >= 0 ? '+' : ''}{data?.change?.toFixed(2)}%
        </div>
        <div className="mt-3">
          <button className={`w-full p-4 rounded-xl text-xl font-black ${
            data?.operation === 'BUY' ? 'bg-[#3fb950] text-white' :
            data?.operation === 'SELL' ? 'bg-[#f85149] text-white' :
            'bg-[#d29922] text-white'
          }`}>
            {data?.operation === 'BUY' ? '🚀 INSTANT BUY' : data?.operation === 'SELL' ? '📉 INSTANT SELL' : '⏳ WAIT'}
          </button>
        </div>
      </div>

      {/* NIFTY 50 */}
      <div className="bg-gradient-to-r from-[#0d1117] to-[#161b22] rounded-xl p-5 border border-[#58a6ff]/30">
        <div className="flex items-center gap-2 mb-3">
          <span className="px-2 py-1 bg-[#58a6ff]/20 text-[#58a6ff] text-xs font-bold rounded">📊</span>
          <span className="text-[#c9d1d9] font-bold text-lg">NIFTY 50</span>
        </div>
        <div className="text-4xl font-bold text-[#c9d1d9]">{niftyData?.lp?.toFixed(2) || '---'}</div>
        <div className={`text-xl font-bold mt-2 ${niftyData?.change >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
          {niftyData?.change >= 0 ? '+' : ''}{niftyData?.change?.toFixed(2)}%
        </div>
      </div>

      {/* Signal Reason */}
      <div className="bg-[#161b22] rounded-xl p-4 border border-[#21262d]">
        <div className="text-[#8b949e] text-sm">{data?.signal_reason || 'Loading...'}</div>
      </div>
    </div>
  );
}

// ============================================
// AI TOOLS TAB - ALL 7 FEATURES
// ============================================
function AIToolsTab({ liveData, prediction, agents, autoTrading, brokerage }: {
  liveData: any;
  prediction: Prediction | null;
  agents: Agent[];
  autoTrading: any;
  brokerage: any;
}) {
  const [view, setView] = useState<'joat' | 'prediction' | 'agents' | 'trading' | 'brokerage'>('joat');

  return (
    <div className="space-y-4">
      {/* Section Header */}
      <div className="bg-gradient-to-r from-[#a371f7]/20 to-[#8957e5]/20 rounded-xl p-4 border border-[#a371f7]/30">
        <div className="text-center">
          <div className="text-xl font-black text-[#a371f7]">⚡ AI TOOLS</div>
          <div className="text-[#8b949e] text-sm mt-1">7 Powerful AI Features</div>
        </div>
      </div>

      {/* Navigation */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { id: 'joat', icon: '📊', label: 'JOAT' },
          { id: 'prediction', icon: '🎯', label: 'AI Prediction' },
          { id: 'agents', icon: '🤖', label: 'Agents' },
          { id: 'trading', icon: '🔄', label: 'Auto Trade' },
          { id: 'brokerage', icon: '🏦', label: 'Brokerage' },
        ].map(item => (
          <button key={item.id} onClick={() => setView(item.id as any)}
            className={`p-3 rounded-xl text-xs font-bold ${view === item.id ? 'bg-[#a371f7] text-white' : 'bg-[#161b22] text-[#8b949e] border border-[#21262d]'}`}>
            {item.icon} {item.label}
          </button>
        ))}
      </div>

      {/* 1. JOAT DIVERGENCE SYSTEM */}
      {view === 'joat' && (
        <div className="space-y-3">
          <div className="bg-[#161b22] rounded-xl p-4 border border-[#a371f7]/30">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-[#a371f7]/20 text-[#a371f7] text-sm font-bold rounded">⚡ JOAT</span>
              <span className="text-[#c9d1d9] font-bold">Divergence System</span>
            </div>
            <div className="text-[#8b949e] text-sm mb-3">6 Oscillators detecting BULL/BEAR divergences</div>
            
            {/* Oscillators Table */}
            <div className="space-y-2">
              {liveData?.oscillators?.map((osc: Oscillator, idx: number) => (
                <div key={idx} className="bg-[#0d1117] p-4 rounded-xl flex justify-between items-center">
                  <div>
                    <span className="font-bold text-lg" style={{ color: osc.color }}>{osc.name}</span>
                    <div className="text-[#8b949e] text-xs">
                      {osc.name === 'RSI' && 'Relative Strength Index'}
                      {osc.name === 'MFI' && 'Money Flow Index'}
                      {osc.name === 'STOCH' && 'Stochastic Oscillator'}
                      {osc.name === 'MACD' && 'MACD Histogram'}
                      {osc.name === 'CCI' && 'Commodity Channel Index'}
                      {osc.name === 'SRSI' && 'Stochastic RSI'}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xl text-[#c9d1d9]">{osc.value.toFixed(1)}</span>
                    {osc.bull && <span className="px-3 py-1 bg-[#3fb950]/20 text-[#3fb950] rounded-lg text-sm font-bold animate-pulse">BULL</span>}
                    {osc.bear && <span className="px-3 py-1 bg-[#f85149]/20 text-[#f85149] rounded-lg text-sm font-bold animate-pulse">BEAR</span>}
                  </div>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="mt-4 p-4 bg-[#0d1117] rounded-xl">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-[#3fb950] text-2xl font-bold">{liveData?.oscillators?.filter((o: Oscillator) => o.bull).length || 0}</div>
                  <div className="text-[#8b949e] text-sm">Bullish Divergences</div>
                </div>
                <div>
                  <div className="text-[#f85149] text-2xl font-bold">{liveData?.oscillators?.filter((o: Oscillator) => o.bear).length || 0}</div>
                  <div className="text-[#8b949e] text-sm">Bearish Divergences</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. AI PREDICTION */}
      {view === 'prediction' && (
        <div className="space-y-3">
          <div className="bg-[#161b22] rounded-xl p-4 border border-[#f0883e]/30">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-[#f0883e]/20 text-[#f0883e] text-sm font-bold rounded">🎯 AI</span>
              <span className="text-[#c9d1d9] font-bold">Prediction Engine</span>
            </div>

            {prediction ? (
              <>
                {/* Direction */}
                <div className={`p-6 rounded-xl text-center mb-4 ${
                  prediction.action === 'BUY' ? 'bg-[#3fb950]/20 border border-[#3fb950]/30' :
                  prediction.action === 'SELL' ? 'bg-[#f85149]/20 border border-[#f85149]/30' :
                  'bg-[#d29922]/20 border border-[#d29922]/30'
                }`}>
                  <div className="text-3xl font-black text-[#c9d1d9]">{prediction.action}</div>
                  <div className="text-[#8b949e] mt-1">{prediction.direction}</div>
                  <div className="text-xl font-bold text-[#a371f7] mt-2">{prediction.confidence}% Confidence</div>
                </div>

                {/* Price Info */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-[#0d1117] p-4 rounded-xl text-center">
                    <div className="text-[#8b949e] text-sm">Current Price</div>
                    <div className="text-[#c9d1d9] font-bold text-xl">₹{prediction.current_price?.toFixed(2)}</div>
                  </div>
                  <div className="bg-[#0d1117] p-4 rounded-xl text-center">
                    <div className="text-[#8b949e] text-sm">Target 1</div>
                    <div className="text-[#3fb950] font-bold text-xl">₹{prediction.target1?.toFixed(2)}</div>
                  </div>
                  <div className="bg-[#0d1117] p-4 rounded-xl text-center">
                    <div className="text-[#8b949e] text-sm">Target 2</div>
                    <div className="text-[#3fb950] font-bold text-xl">₹{prediction.target2?.toFixed(2)}</div>
                  </div>
                  <div className="bg-[#0d1117] p-4 rounded-xl text-center">
                    <div className="text-[#8b949e] text-sm">Stop Loss</div>
                    <div className="text-[#f85149] font-bold text-xl">₹{prediction.stoploss?.toFixed(2)}</div>
                  </div>
                </div>

                {/* Signals */}
                <div className="bg-[#0d1117] p-4 rounded-xl">
                  <div className="text-[#8b949e] text-sm mb-2">Signal Sources:</div>
                  <div className="flex flex-wrap gap-2">
                    {prediction.signals?.map((sig, i) => (
                      <span key={i} className="px-3 py-1 bg-[#21262d] text-[#c9d1d9] rounded-lg text-sm">{sig}</span>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-8 text-[#8b949e]">Loading AI Prediction...</div>
            )}
          </div>
        </div>
      )}

      {/* 3. SIGNAL AGENTS */}
      {view === 'agents' && (
        <div className="space-y-3">
          <div className="bg-[#161b22] rounded-xl p-4 border border-[#58a6ff]/30">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-[#58a6ff]/20 text-[#58a6ff] text-sm font-bold rounded">🤖</span>
              <span className="text-[#c9d1d9] font-bold">Signal Agents</span>
            </div>
            <div className="text-[#8b949e] text-sm mb-3">6 AI Agents with different strategies</div>

            {agents?.length > 0 ? (
              <div className="space-y-2">
                {agents.map((agent, idx) => (
                  <div key={idx} className="bg-[#0d1117] p-4 rounded-xl">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{agent.icon}</span>
                        <div>
                          <div className="text-[#c9d1d9] font-bold">{agent.name}</div>
                          <div className="text-[#8b949e] text-xs">{agent.reason}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`px-3 py-1 rounded-lg text-sm font-bold ${
                          agent.signal === 'BUY' ? 'bg-[#3fb950]/20 text-[#3fb950]' :
                          agent.signal === 'SELL' ? 'bg-[#f85149]/20 text-[#f85149]' :
                          'bg-[#d29922]/20 text-[#d29922]'
                        }`}>{agent.signal}</span>
                        <div className="text-[#8b949e] text-xs mt-1">{agent.strength}% | {agent.accuracy}% acc</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-[#8b949e]">Loading Signal Agents...</div>
            )}
          </div>
        </div>
      )}

      {/* 4. AUTO TRADING */}
      {view === 'trading' && (
        <div className="space-y-3">
          <div className="bg-[#161b22] rounded-xl p-4 border border-[#3fb950]/30">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-[#3fb950]/20 text-[#3fb950] text-sm font-bold rounded">🔄</span>
              <span className="text-[#c9d1d9] font-bold">Auto Trading Bot</span>
            </div>

            {/* Status */}
            <div className={`p-4 rounded-xl mb-4 ${autoTrading?.enabled ? 'bg-[#3fb950]/20 border border-[#3fb950]/30' : 'bg-[#f85149]/20 border border-[#f85149]/30'}`}>
              <div className="flex justify-between items-center">
                <div>
                  <div className={`font-bold text-lg ${autoTrading?.enabled ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                    Bot: {autoTrading?.enabled ? 'RUNNING' : 'STOPPED'}
                  </div>
                  <div className="text-[#8b949e] text-sm">AI executes trades automatically</div>
                </div>
                <div className={`w-4 h-4 rounded-full ${autoTrading?.enabled ? 'bg-[#3fb950] animate-pulse' : 'bg-[#f85149]'}`} />
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#0d1117] p-4 rounded-xl text-center">
                <div className="text-[#58a6ff] text-2xl font-bold">{autoTrading?.positions_count || 0}</div>
                <div className="text-[#8b949e] text-sm">Open Positions</div>
              </div>
              <div className="bg-[#0d1117] p-4 rounded-xl text-center">
                <div className="text-[#a371f7] text-2xl font-bold">{autoTrading?.last_signal?.signal || 'WAIT'}</div>
                <div className="text-[#8b949e] text-sm">Last Signal</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. BROKERAGE INTEGRATION */}
      {view === 'brokerage' && (
        <div className="space-y-3">
          <div className="bg-[#161b22] rounded-xl p-4 border border-[#d29922]/30">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-[#d29922]/20 text-[#d29922] text-sm font-bold rounded">🏦</span>
              <span className="text-[#c9d1d9] font-bold">Brokerage Integration</span>
            </div>

            {brokerage ? (
              <div className="space-y-2">
                {Object.entries(brokerage).map(([name, data]: [string, any]) => (
                  <div key={name} className="bg-[#0d1117] p-4 rounded-xl flex justify-between items-center">
                    <div>
                      <div className="text-[#c9d1d9] font-bold capitalize">{name}</div>
                      <div className="text-[#8b949e] text-xs">Orders today: {data.orders_today}</div>
                    </div>
                    <span className={`px-3 py-1 rounded-lg text-sm font-bold ${data.status === 'Connected' ? 'bg-[#3fb950]/20 text-[#3fb950]' : 'bg-[#f85149]/20 text-[#f85149]'}`}>
                      {data.status}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-[#8b949e]">Loading Brokerage Status...</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// WALLET TAB
// ============================================
function WalletTab({ wallet, transactions, onCredit, onDebit, autoTrading, onToggleAuto }: {
  wallet: any;
  transactions: any[];
  onCredit: (amount: number, desc: string) => void;
  onDebit: (amount: number, desc: string) => void;
  autoTrading: any;
  onToggleAuto: () => void;
}) {
  const [showCredit, setShowCredit] = useState(false);
  const [showDebit, setShowDebit] = useState(false);
  const [amount, setAmount] = useState('');
  const [desc, setDesc] = useState('');

  return (
    <div className="space-y-4">
      {/* Balance */}
      <div className="bg-gradient-to-r from-[#161b22] to-[#1f2937] rounded-xl p-5 border border-[#3fb950]/30">
        <div className="text-center">
          <div className="text-[#8b949e] text-sm">Balance</div>
          <div className="text-4xl font-bold text-[#3fb950]">₹{wallet?.balance?.toLocaleString('en-IN') || '0'}</div>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-[#21262d]">
          <div className="text-center">
            <div className="text-[#8b949e] text-xs">Credit</div>
            <div className="text-[#3fb950] font-bold">₹{wallet?.total_credit?.toLocaleString('en-IN') || '0'}</div>
          </div>
          <div className="text-center">
            <div className="text-[#8b949e] text-xs">Debit</div>
            <div className="text-[#f85149] font-bold">₹{wallet?.total_debit?.toLocaleString('en-IN') || '0'}</div>
          </div>
          <div className="text-center">
            <div className="text-[#8b949e] text-xs">P&L</div>
            <div className={`${(wallet?.net_pnl || 0) >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'} font-bold`}>
              ₹{wallet?.net_pnl?.toLocaleString('en-IN') || '0'}
            </div>
          </div>
        </div>
      </div>

      {/* Auto Trading Toggle */}
      <div className="bg-[#161b22] rounded-xl p-4 border border-[#21262d]">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[#c9d1d9] font-bold">🔄 Auto Trading</div>
            <div className="text-[#8b949e] text-xs">AI executes trades automatically</div>
          </div>
          <button onClick={onToggleAuto}
            className={`px-4 py-2 rounded-xl font-bold ${autoTrading?.enabled ? 'bg-[#3fb950] text-white' : 'bg-[#21262d] text-[#8b949e]'}`}>
            {autoTrading?.enabled ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      {/* Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <button onClick={() => setShowCredit(!showCredit)} className="p-4 bg-[#3fb950] rounded-xl text-white font-bold">➕ CREDIT</button>
        <button onClick={() => setShowDebit(!showDebit)} className="p-4 bg-[#f85149] rounded-xl text-white font-bold">➖ DEBIT</button>
      </div>

      {/* Forms */}
      {showCredit && (
        <div className="bg-[#161b22] border border-[#3fb950]/30 rounded-xl p-4 space-y-3">
          <input type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-3 bg-[#0d1117] border border-[#21262d] rounded-lg text-white" />
          <input type="text" placeholder="Description" value={desc} onChange={e => setDesc(e.target.value)} className="w-full p-3 bg-[#0d1117] border border-[#21262d] rounded-lg text-white" />
          <button onClick={() => { onCredit(parseFloat(amount), desc || 'Credit'); setAmount(''); setDesc(''); setShowCredit(false); }} className="w-full p-3 bg-[#3fb950] rounded-lg text-white font-bold">Add Credit</button>
        </div>
      )}

      {showDebit && (
        <div className="bg-[#161b22] border border-[#f85149]/30 rounded-xl p-4 space-y-3">
          <input type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} className="w-full p-3 bg-[#0d1117] border border-[#21262d] rounded-lg text-white" />
          <input type="text" placeholder="Description" value={desc} onChange={e => setDesc(e.target.value)} className="w-full p-3 bg-[#0d1117] border border-[#21262d] rounded-lg text-white" />
          <button onClick={() => { onDebit(parseFloat(amount), desc || 'Debit'); setAmount(''); setDesc(''); setShowDebit(false); }} className="w-full p-3 bg-[#f85149] rounded-lg text-white font-bold">Add Debit</button>
        </div>
      )}

      {/* Transactions */}
      <div className="bg-[#161b22] rounded-xl p-4 border border-[#21262d]">
        <div className="text-[#8b949e] text-xs uppercase mb-3 font-bold">Transaction History</div>
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {transactions.slice(0, 10).map(txn => (
            <div key={txn.id} className={`p-3 rounded-lg ${txn.type === 'CREDIT' ? 'bg-[#3fb950]/10' : 'bg-[#f85149]/10'}`}>
              <div className="flex justify-between">
                <span className={`text-xs font-bold ${txn.type === 'CREDIT' ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>{txn.type}</span>
                <span className={`font-bold ${txn.type === 'CREDIT' ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                  {txn.type === 'CREDIT' ? '+' : '-'}₹{txn.amount.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="text-[#8b949e] text-xs">{txn.description}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================
// ADMIN TAB
// ============================================
function AdminTab({ stats, users, allTransactions, selectedUser, onSelectUser, onCredit, onDebit, onReset }: {
  stats: any;
  users: any[];
  allTransactions: any[];
  selectedUser: any;
  onSelectUser: (user: any) => void;
  onCredit: (userId: string, amount: number, desc: string) => void;
  onDebit: (userId: string, amount: number, desc: string) => void;
  onReset: (userId: string) => void;
}) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [view, setView] = useState<'dashboard' | 'users' | 'transactions'>('dashboard');
  const [creditAmount, setCreditAmount] = useState('');
  const [creditDesc, setCreditDesc] = useState('');

  if (!isLoggedIn) {
    return (
      <div className="space-y-4">
        <div className="bg-[#161b22] rounded-xl p-5 border border-[#a371f7]/30">
          <div className="text-center mb-4">
            <span className="px-3 py-1 bg-[#a371f7]/20 text-[#a371f7] text-sm font-bold rounded-full">⚙️ ADMIN LOGIN</span>
          </div>
          <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} className="w-full p-3 mb-2 bg-[#0d1117] border border-[#21262d] rounded-lg text-white" />
          <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-3 mb-3 bg-[#0d1117] border border-[#21262d] rounded-lg text-white" />
          <button onClick={async () => {
            const res = await fetch(`${FLASK_API}/admin/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }) });
            const data = await res.json();
            if (data.success) setIsLoggedIn(true);
          }} className="w-full p-3 bg-[#a371f7] rounded-lg text-white font-bold">🔐 LOGIN</button>
          <div className="text-center text-[#8b949e] text-xs mt-3">admin / spider@123</div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Navigation */}
      <div className="grid grid-cols-3 gap-2">
        <button onClick={() => setView('dashboard')} className={`p-3 rounded-xl font-bold ${view === 'dashboard' ? 'bg-[#a371f7] text-white' : 'bg-[#161b22] text-[#8b949e]'}`}>📊 Dashboard</button>
        <button onClick={() => setView('users')} className={`p-3 rounded-xl font-bold ${view === 'users' ? 'bg-[#a371f7] text-white' : 'bg-[#161b22] text-[#8b949e]'}`}>👥 Users</button>
        <button onClick={() => setView('transactions')} className={`p-3 rounded-xl font-bold ${view === 'transactions' ? 'bg-[#a371f7] text-white' : 'bg-[#161b22] text-[#8b949e]'}`}>📜 Txns</button>
      </div>

      {/* Dashboard */}
      {view === 'dashboard' && stats && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#161b22] p-4 rounded-xl text-center border border-[#21262d]">
              <div className="text-[#8b949e] text-sm">Total Users</div>
              <div className="text-2xl font-bold text-[#58a6ff]">{stats.total_users}</div>
            </div>
            <div className="bg-[#161b22] p-4 rounded-xl text-center border border-[#21262d]">
              <div className="text-[#8b949e] text-sm">Total Balance</div>
              <div className="text-lg font-bold text-[#a371f7]">₹{stats.total_balance?.toLocaleString('en-IN')}</div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-[#161b22] to-[#0d1117] rounded-xl p-5 border border-[#21262d]">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-[#8b949e] text-sm">Total Profit</div>
                <div className="text-xl font-bold text-[#3fb950]">₹{stats.total_profit?.toLocaleString('en-IN')}</div>
              </div>
              <div className="text-center">
                <div className="text-[#8b949e] text-sm">Total Loss</div>
                <div className="text-xl font-bold text-[#f85149]">₹{stats.total_loss?.toLocaleString('en-IN')}</div>
              </div>
            </div>
            <div className="text-center mt-4 pt-4 border-t border-[#21262d]">
              <div className="text-[#8b949e] text-sm">Net P&L</div>
              <div className={`text-2xl font-bold ${stats.net_pnl >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                ₹{stats.net_pnl?.toLocaleString('en-IN')}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Users */}
      {view === 'users' && (
        <div className="space-y-3">
          {users.map(user => (
            <div key={user.id} className="bg-[#161b22] rounded-xl p-4 border border-[#21262d] cursor-pointer" onClick={() => onSelectUser(user)}>
              <div className="flex justify-between items-center mb-2">
                <div className="font-bold text-[#c9d1d9]">{user.name}</div>
                <span className={`px-2 py-1 rounded text-xs font-bold ${user.status === 'active' ? 'bg-[#3fb950]/20 text-[#3fb950]' : 'bg-[#f85149]/20 text-[#f85149]'}`}>
                  {user.status.toUpperCase()}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="bg-[#0d1117] p-2 rounded text-center">
                  <div className="text-[#8b949e]">Balance</div>
                  <div className="text-[#3fb950] font-bold">₹{user.balance.toLocaleString('en-IN')}</div>
                </div>
                <div className="bg-[#0d1117] p-2 rounded text-center">
                  <div className="text-[#8b949e]">P&L</div>
                  <div className={`${user.net_pnl >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'} font-bold`}>₹{user.net_pnl.toLocaleString('en-IN')}</div>
                </div>
                <div className="bg-[#0d1117] p-2 rounded text-center">
                  <div className="text-[#8b949e]">Win%</div>
                  <div className="text-[#a371f7] font-bold">{user.win_rate}%</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Transactions */}
      {view === 'transactions' && (
        <div className="space-y-2 max-h-[400px] overflow-y-auto">
          {allTransactions.slice(0, 20).map(txn => (
            <div key={`${txn.id}-${txn.user_id}`} className={`p-3 rounded-xl ${txn.type === 'CREDIT' ? 'bg-[#3fb950]/10' : 'bg-[#f85149]/10'}`}>
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-[#c9d1d9] text-sm">{txn.user_name}</span>
                  <span className={`ml-2 px-2 py-0.5 rounded text-xs font-bold ${txn.type === 'CREDIT' ? 'bg-[#3fb950]/20 text-[#3fb950]' : 'bg-[#f85149]/20 text-[#f85149]'}`}>
                    {txn.type}
                  </span>
                </div>
                <span className={`font-bold ${txn.type === 'CREDIT' ? 'text-[#3fb950]' : 'text-[#f85149]'}`}>
                  {txn.type === 'CREDIT' ? '+' : '-'}₹{txn.amount.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="text-[#8b949e] text-xs">{txn.description}</div>
            </div>
          ))}
        </div>
      )}

      {/* User Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0d1117] rounded-2xl p-5 max-w-sm w-full border border-[#21262d]">
            <div className="flex justify-between items-center mb-4">
              <div className="font-bold text-lg text-[#c9d1d9]">{selectedUser.name}</div>
              <button onClick={() => onSelectUser(null)} className="text-[#8b949e] text-xl">&times;</button>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-[#161b22] p-3 rounded-lg text-center">
                <div className="text-[#8b949e] text-xs">Balance</div>
                <div className="text-[#3fb950] font-bold">₹{selectedUser.balance.toLocaleString('en-IN')}</div>
              </div>
              <div className="bg-[#161b22] p-3 rounded-lg text-center">
                <div className="text-[#8b949e] text-xs">Net P&L</div>
                <div className={`${selectedUser.net_pnl >= 0 ? 'text-[#3fb950]' : 'text-[#f85149]'} font-bold`}>
                  ₹{selectedUser.net_pnl.toLocaleString('en-IN')}
                </div>
              </div>
            </div>
            <div className="flex gap-2 mb-3">
              <input type="number" placeholder="Amount" value={creditAmount} onChange={e => setCreditAmount(e.target.value)} className="flex-1 p-2 bg-[#161b22] border border-[#21262d] rounded text-white text-sm" />
              <input type="text" placeholder="Desc" value={creditDesc} onChange={e => setCreditDesc(e.target.value)} className="flex-1 p-2 bg-[#161b22] border border-[#21262d] rounded text-white text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => { onCredit(selectedUser.id, parseFloat(creditAmount), creditDesc || 'Admin Credit'); setCreditAmount(''); setCreditDesc(''); }} className="p-2 bg-[#3fb950] rounded text-white font-bold text-sm">➕ Credit</button>
              <button onClick={() => { onDebit(selectedUser.id, parseFloat(creditAmount), creditDesc || 'Admin Debit'); setCreditAmount(''); setCreditDesc(''); }} className="p-2 bg-[#f85149] rounded text-white font-bold text-sm">➖ Debit</button>
            </div>
            <button onClick={() => { onReset(selectedUser.id); onSelectUser(null); }} className="w-full mt-2 p-2 bg-[#d29922] rounded text-white font-bold text-sm">🔄 Reset Wallet</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// ABOUT TAB
// ============================================
function AboutTab() {
  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-[#161b22] to-[#0d1117] rounded-xl p-5 border border-[#21262d] text-center">
        <div className="font-black text-2xl bg-gradient-to-r from-[#58a6ff] via-[#a371f7] to-[#f0883e] bg-clip-text text-transparent">DivergeX AI Market</div>
        <div className="text-[#8b949e] text-sm">AI-Powered Trading System</div>
        <div className="flex justify-center gap-2 mt-3">
          <span className="text-xs text-white bg-gradient-to-r from-[#58a6ff] to-[#a371f7] px-3 py-1 rounded-full font-bold">DIVERGEX AI</span>
        </div>
      </div>
      
      <div className="bg-[#161b22] rounded-xl p-4 border border-[#21262d]">
        <div className="text-[#c9d1d9] font-bold mb-3">🚀 AI Features (7 Tools)</div>
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-[#3fb950]"><span>✓</span> JOAT Divergence System (6 Oscillators)</div>
          <div className="flex items-center gap-2 text-[#3fb950]"><span>✓</span> Real-time NIFTY 50 & BANK NIFTY</div>
          <div className="flex items-center gap-2 text-[#3fb950]"><span>✓</span> Signal Agents (6 AI Agents)</div>
          <div className="flex items-center gap-2 text-[#3fb950]"><span>✓</span> AI Prediction Engine</div>
          <div className="flex items-center gap-2 text-[#3fb950]"><span>✓</span> Auto Trading System</div>
          <div className="flex items-center gap-2 text-[#3fb950]"><span>✓</span> Virtual Trading</div>
          <div className="flex items-center gap-2 text-[#3fb950]"><span>✓</span> Brokerage Integration</div>
        </div>
      </div>
      
      <div className="bg-[#161b22] rounded-xl p-4 border border-[#21262d]">
        <div className="text-[#c9d1d9] font-bold mb-2">👨‍💻 Developer</div>
        <div className="text-[#c9d1d9] font-bold">Dafda Rohit</div>
        <div className="text-[#8b949e] text-sm">📞 8140644470</div>
        <div className="text-[#8b949e] text-sm">📧 DafdaRohit@yahoo.com</div>
      </div>
    </div>
  );
}

// ============================================
// MAIN PAGE
// ============================================
export default function SpiderQuantDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>('live');
  const [liveData, setLiveData] = useState<any>(null);
  const [niftyData, setNiftyData] = useState<any>(null);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [brokerage, setBrokerage] = useState<any>(null);
  const [autoTrading, setAutoTrading] = useState<any>({ enabled: false });
  const [wallet, setWallet] = useState<any>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [adminStats, setAdminStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [allTransactions, setAllTransactions] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [backendStatus, setBackendStatus] = useState<'connected' | 'disconnected'>('disconnected');
  const [userId] = useState('user_001');

  const checkBackend = async () => {
    try {
      const res = await fetch(`${FLASK_API}/`);
      setBackendStatus(res.ok ? 'connected' : 'disconnected');
    } catch { setBackendStatus('disconnected'); }
  };

  const fetchLiveData = async () => {
    try { const res = await fetch(`${FLASK_API}/get-live-data`); if (res.ok) setLiveData(await res.json()); } catch {}
  };

  const fetchNiftyData = async () => {
    try { const res = await fetch(`${FLASK_API}/get-nifty-data`); if (res.ok) setNiftyData(await res.json()); } catch {}
  };

  const fetchPrediction = async () => {
    try { const res = await fetch(`${FLASK_API}/get-ai-prediction`); if (res.ok) setPrediction(await res.json()); } catch {}
  };

  const fetchAgents = async () => {
    try { const res = await fetch(`${FLASK_API}/get-signal-agents`); if (res.ok) { const d = await res.json(); setAgents(d.agents || []); } } catch {}
  };

  const fetchBrokerage = async () => {
    try { const res = await fetch(`${FLASK_API}/get-brokerage-status`); if (res.ok) setBrokerage(await res.json()); } catch {}
  };

  const fetchAutoTrading = async () => {
    try { const res = await fetch(`${FLASK_API}/auto-trading/status`); if (res.ok) setAutoTrading(await res.json()); } catch {}
  };

  const fetchWallet = async () => {
    try { const res = await fetch(`${FLASK_API}/get-wallet?user_id=${userId}`); if (res.ok) setWallet(await res.json()); } catch {}
  };

  const fetchTransactions = async () => {
    try { const res = await fetch(`${FLASK_API}/get-transactions?user_id=${userId}`); if (res.ok) { const d = await res.json(); setTransactions(d.transactions || []); } } catch {}
  };

  const fetchAdminData = async () => {
    try {
      const [statsRes, usersRes, txnsRes] = await Promise.all([
        fetch(`${FLASK_API}/admin/stats`),
        fetch(`${FLASK_API}/admin/users`),
        fetch(`${FLASK_API}/admin/all-transactions`)
      ]);
      if (statsRes.ok) setAdminStats(await statsRes.json());
      if (usersRes.ok) { const d = await usersRes.json(); setUsers(d.users || []); }
      if (txnsRes.ok) { const d = await txnsRes.json(); setAllTransactions(d.transactions || []); }
    } catch {}
  };

  const handleCredit = async (amount: number, desc: string) => {
    await fetch(`${FLASK_API}/add-credit`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: userId, amount, description: desc }) });
    fetchWallet(); fetchTransactions();
  };

  const handleDebit = async (amount: number, desc: string) => {
    await fetch(`${FLASK_API}/add-debit`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: userId, amount, description: desc }) });
    fetchWallet(); fetchTransactions();
  };

  const handleToggleAuto = async () => {
    await fetch(`${FLASK_API}/auto-trading/toggle`, { method: 'POST' });
    fetchAutoTrading();
  };

  const handleAdminCredit = async (uid: string, amount: number, desc: string) => {
    await fetch(`${FLASK_API}/admin/user/${uid}/add-credit`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ amount, description: desc }) });
    fetchAdminData();
  };

  const handleAdminDebit = async (uid: string, amount: number, desc: string) => {
    await fetch(`${FLASK_API}/admin/user/${uid}/add-debit`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ amount, description: desc }) });
    fetchAdminData();
  };

  const handleReset = async (uid: string) => {
    await fetch(`${FLASK_API}/admin/reset-user/${uid}`, { method: 'POST' });
    fetchAdminData();
  };

  useEffect(() => {
    checkBackend();
    fetchLiveData();
    fetchNiftyData();
    const interval = setInterval(() => { checkBackend(); fetchLiveData(); fetchNiftyData(); }, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (activeTab === 'wallet') { fetchWallet(); fetchTransactions(); fetchAutoTrading(); }
    if (activeTab === 'admin') fetchAdminData();
    if (activeTab === 'ai_tools') { fetchPrediction(); fetchAgents(); fetchBrokerage(); fetchAutoTrading(); }
  }, [activeTab]);

  const tabs: { id: TabType; icon: string; label: string }[] = [
    { id: 'live', icon: '🔴', label: 'LIVE' },
    { id: 'ai_tools', icon: '⚡', label: 'AI TOOLS' },
    { id: 'wallet', icon: '💰', label: 'WALLET' },
    { id: 'admin', icon: '⚙️', label: 'ADMIN' },
    { id: 'about', icon: '👤', label: 'ABOUT' },
  ];

  return (
    <div className="min-h-screen bg-[#010409] text-[#c9d1d9] flex flex-col">
      {/* Header */}
      <div className="h-14 bg-[#0d1117] border-b border-[#21262d] flex items-center px-4 justify-between">
        <div className="flex items-center gap-3">
          <div className="font-black text-xl bg-gradient-to-r from-[#58a6ff] via-[#a371f7] to-[#f0883e] bg-clip-text text-transparent">DivergeX</div>
          <span className="text-xs text-white bg-gradient-to-r from-[#58a6ff] to-[#a371f7] px-2 py-1 rounded-full font-bold">AI</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-[#3fb950]/10 px-3 py-1.5 rounded-xl border border-[#3fb950]/30">
            <span className="text-lg">💰</span>
            <span className="text-[#3fb950] font-bold">₹{wallet?.balance?.toLocaleString('en-IN', { maximumFractionDigits: 0 }) || '0'}</span>
          </div>
          <div className={`flex items-center gap-2 text-xs px-3 py-1.5 rounded-xl ${backendStatus === 'connected' ? 'bg-[#3fb950]/10 text-[#3fb950] border border-[#3fb950]/30' : 'bg-[#f85149]/10 text-[#f85149] border border-[#f85149]/30'}`}>
            <span className={`w-2 h-2 rounded-full ${backendStatus === 'connected' ? 'bg-[#3fb950] animate-pulse' : 'bg-[#f85149]'}`}></span>
            {backendStatus === 'connected' ? 'ONLINE' : 'OFFLINE'}
          </div>
        </div>
      </div>

      {/* Main Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-[380px] bg-gradient-to-b from-[#0d1117] to-[#010409] flex flex-col border-r border-[#21262d] overflow-hidden">
          <div className="flex bg-[#010409] border-b border-[#21262d] p-1 gap-1">
            {tabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex-1 py-3 text-sm font-bold rounded-lg flex items-center justify-center gap-1 ${activeTab === tab.id ? 'text-[#58a6ff] bg-[#0d1117]' : 'text-[#8b949e]'}`}>
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
          <div className="flex-1 overflow-y-auto p-3">
            {activeTab === 'live' && <LiveTab data={liveData} niftyData={niftyData} />}
            {activeTab === 'ai_tools' && <AIToolsTab liveData={liveData} prediction={prediction} agents={agents} autoTrading={autoTrading} brokerage={brokerage} />}
            {activeTab === 'wallet' && <WalletTab wallet={wallet} transactions={transactions} onCredit={handleCredit} onDebit={handleDebit} autoTrading={autoTrading} onToggleAuto={handleToggleAuto} />}
            {activeTab === 'admin' && <AdminTab stats={adminStats} users={users} allTransactions={allTransactions} selectedUser={selectedUser} onSelectUser={setSelectedUser} onCredit={handleAdminCredit} onDebit={handleAdminDebit} onReset={handleReset} />}
            {activeTab === 'about' && <AboutTab />}
          </div>
        </div>

        {/* Chart Area */}
        <div className="flex-1 bg-[#010409] flex items-center justify-center p-4">
          {liveData?.chart_data ? (
            <ApexCharts
              options={{
                chart: { type: 'candlestick', background: 'transparent', toolbar: { show: false } },
                xaxis: { type: 'datetime', labels: { style: { colors: '#8b949e' } } },
                yaxis: { labels: { style: { colors: '#8b949e' } } },
                grid: { borderColor: '#21262d' },
                candlestick: { colors: { upward: '#3fb950', downward: '#f85149' } }
              }}
              series={[{ type: 'candlestick', data: liveData.chart_data.ohlc }]}
              type="candlestick"
              height="100%"
            />
          ) : (
            <div className="text-[#8b949e] text-lg">Loading chart...</div>
          )}
        </div>
      </div>
    </div>
  );
}
